﻿using PROJ_ValorantAgents.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJ_ValorantAgents.Resources.Data
{
    internal class DesignTimeData
    {
        public List<Agent> Agents { get; set; }

    }
}
