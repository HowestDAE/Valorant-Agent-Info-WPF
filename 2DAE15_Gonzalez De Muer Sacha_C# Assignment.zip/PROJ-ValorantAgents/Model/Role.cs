﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJ_ValorantAgents.Model
{
    //public class Role
    //{
    //    public string displayName { get; set; } = "INITIATOR";
    //    public string? displayIcon { get; set; } = "https://media.valorant-api.com/agents/roles/dbe8757e-9e92-4ed4-b39f-9dfc589691d4/displayicon.png";
    //}
}
